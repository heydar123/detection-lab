# Presenting this project

This is a lab you built and can explain. It is not production experience, so describe it as exactly that.
Interviewers can tell the difference, and being precise makes you more credible, not less.

## Resume bullets (pick two or three, keep them accurate)

- Built a detection-as-code lab of six ATT&CK-mapped rules (credential access, execution, persistence) in version-controlled
  YAML, with a linter that rejects rules lacking an ATT&CK mapping, triage steps, or a written reason for each exclusion.
- Measured detection quality against a synthetic dataset with six labeled attack scenarios: untuned rules raised 40 alerts at
  25% precision; documented tuning cut them to 10 alerts at 100% precision with no missed scenarios.
- Wrote a test suite (44 tests) that checks every rule across multiple random seeds, so a rule change that breaks a
  detection or adds false positives fails the build.
- Produced an incident case file (timeline, ATT&CK sequence, triage questions, response steps) for a simulated account-takeover
  kill chain.

Replace the numbers with your own if you change the dataset. Do not write "reduced false positives by 75% in
production" or anything that implies a real environment.

## 60-second pitch

"I wanted proof that I can do the part of the job where detections get built and maintained, not just triage alerts. So I built
a small detection-as-code lab. The rules are YAML in version control, they run against synthetic logs with six hidden attacks, and
each rule gets a precision and recall score. The first version of my rules caught every attack but had 25% precision, because a
vulnerability scanner, a backup job, and a VPN were all tripping them. I tuned them with exclusions that each have a documented
reason, got to zero false positives, and wrote tests so the tuning can't silently regress. The part I'd improve next is correlating
alerts into cases, because one intrusion currently raises several separate alerts."

## Questions to expect, and where the answer is

| Question | Where to point |
|---|---|
| How do you decide a threshold? | DET-001 and DET-002: 20 failures in 5 min and 10 accounts in 30 min were chosen against the benign typo rate and the scanner burst. Explain what you'd measure in real data. |
| How do you handle false positives? | The untuned vs tuned table; the exclusion `reason` field; `test_backup_user_on_another_host_would_still_alert`. |
| What is the downside of an exclusion? | The `it.admin` note in DET-006: it blinds the rule if that account is compromised. |
| Walk me through an investigation. | `docs/sample-incident-report.md`. |
| What would you improve? | The limitations and "Ideas to extend it" sections of the README. |
| How would this run in our SIEM? | The KQL and SPL drafts in each rule. Be upfront that they are untested drafts. |

## Make it stronger before you send it

1. Run the KQL drafts in a free Microsoft Sentinel or Splunk instance, fix what breaks, and note the fixes in the README.
2. Replay one public attack dataset through the engine and write up what the rules missed. Honest misses read better than a perfect score.
3. Add one rule of your own for something you have actually seen at work, with its own scenario and tests.
4. Put it on GitHub with the CI workflow enabled so the passing build is visible.

## Using it for a promotion case where you work now

The same method transfers directly. Pick one alert your team finds noisy, measure how many alerts per week are false
positives, tune it with documented exclusions, and report the before and after numbers to your manager. Keep the original rule,
the change, and the measurement in version control. "I cut a noisy alert's false positives from X to Y and wrote down
why" is a concrete, checkable accomplishment.
