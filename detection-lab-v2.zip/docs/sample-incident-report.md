# Incident case file: `d.okafor`

_Generated from synthetic lab data by detlab. Every name, IP, and host in this file is fictional._

## Summary

- Highest severity: **critical**
- Alerts involving this account: 4 across 4 detection rules
- Observed tactic sequence: Credential Access -> Execution -> Persistence
- Window: 2026-10-09T09:30:02Z to 2026-10-09T10:05:00Z (UTC)

## Alerts

| Alert | Time (UTC) | Rule | Severity | ATT&CK | What fired |
|---|---|---|---|---|---|
| A-0003 | 2026-10-09T09:30:02Z | DET-001 | medium | T1110.001 | 40 matching events over 349s (src_ip=203.0.113.77, user=d.okafor) |
| A-0004 | 2026-10-09T09:30:02Z | DET-005 | critical | T1110 | 40 failures then a success within 900s (user=d.okafor, src_ip=203.0.113.77) |
| A-0005 | 2026-10-09T09:48:00Z | DET-004 | high | T1059.001 | Encoded PowerShell command line (user=d.okafor, host=WS-003) |
| A-0006 | 2026-10-09T10:05:00Z | DET-006 | critical | T1098 | Privileged group membership change by an unapproved account (user=d.okafor, target_user=d.okafor, group=Domain Admins) |

## Timeline

| Time (UTC) | Event | Alert |
|---|---|---|
| 2026-10-09T09:30:02Z | 40 failed rdp logins for `d.okafor` from 203.0.113.77 (BR), last at 09:35:51Z | A-0003, A-0004 |
| 2026-10-09T09:37:00Z | success rdp login for `d.okafor` from 203.0.113.77 (BR) | A-0004 |
| 2026-10-09T09:48:00Z | `powershell.exe` started on WS-003 by `d.okafor` (parent `cmd.exe`): `powershell.exe -nop -w hidden -enc VwByAGkAdABlAC0ATwB1AHQAcAB1AHQAIAAnAGQAZQB0AGwAYQBiAC0AcwBhAG0AcABsAGUALQB...` | A-0005 |
| 2026-10-09T10:05:00Z | `d.okafor` added `d.okafor` to **Domain Admins** on DC-01 | A-0006 |

## Triage questions

- DET-001: Is the source IP internal or external? Check reputation and geolocation.
- DET-001: Did any success follow the failures for the same account (see DET-005)?
- DET-001: Is the account privileged or a service account?
- DET-001: Check whether the account is locked out and whether lockout policy is working.
- DET-005: Treat as a likely compromise until proven otherwise.
- DET-005: Identify everything the account did after the successful login.
- DET-005: Check for new MFA registrations, mailbox rules, or privilege changes after the login.
- DET-004: Decode the base64 (UTF-16LE) and read what it does.
- DET-004: Check the parent process - Office apps, browsers, and script hosts are red flags.
- DET-004: Look at what else ran on the host in the 10 minutes around the event.
- DET-004: Check for outbound network connections from the PowerShell process.
- DET-006: Was there a change ticket? Who approved it?
- DET-006: Is the actor the same account being added (self-escalation)?
- DET-006: What did the actor do in the hour before the change?

## Recommended response

- DET-001: Block or rate-limit the source IP at the perimeter.
- DET-001: If a success followed, treat the account as compromised - reset credentials and revoke sessions.
- DET-001: Enforce MFA on the targeted service if it is exposed to the internet.
- DET-005: Disable the account or force a password reset and revoke all sessions immediately.
- DET-005: Isolate any host the account logged in to.
- DET-005: Hunt for follow-on activity: new processes (DET-004) and group changes (DET-006).
- DET-004: Isolate the host if the decoded command downloads or executes something.
- DET-004: Collect the process tree and the decoded payload as evidence.
- DET-004: Hunt for the same command line or parent process across the fleet.
- DET-006: Remove the unapproved membership and disable the actor account if it is not legitimate.
- DET-006: Review all actions taken with the elevated rights since the change.
- DET-006: Reset credentials for any privileged account that may have been exposed.

## Analyst assessment

This case is synthetic and was generated from the lab dataset. The assessment below is based only on the timeline above.

**What happened.** An external address (203.0.113.77, geolocated to Brazil in the lab data) made 40 failed RDP logins against
`d.okafor` in about six minutes and then logged in successfully at 09:37:00Z. Eleven minutes later a hidden, encoded
PowerShell command ran on the user's workstation (WS-003) with `cmd.exe` as its parent. Seventeen minutes after that, `d.okafor` added
its own account to Domain Admins on DC-01. In the lab, the decoded payload is a harmless `Write-Output`; in a real case,
decoding it would be the first step.

**Confidence.** High that this is a compromise rather than a user error: the account is not a service account, the failures came from one
external source at machine speed, and the privilege change was a self-escalation with no change ticket in this dataset.

**Detection timing.** DET-001 would have fired about three minutes into the brute force, after the 20th failure, which is the earliest
point a defender could have acted. DET-005 fired at the successful login (09:37:00Z). That left roughly 28 minutes before the
Domain Admins change (10:05:00Z) to disable the account and revoke sessions.

**Gaps this case exposes.**
- Nothing in the lab detects discovery or lateral movement between the PowerShell execution and the group change.
- RDP was reachable from an external address. Closing that exposure or requiring a gateway with MFA is the preventive control.
- DET-001 and DET-005 are separate alerts for one event chain. Correlating alerts by account into a single case is the next improvement.

**Immediate actions (priority order).**
1. Disable `d.okafor`, revoke all sessions, and remove the account from Domain Admins.
2. Isolate WS-003 and collect the process tree and the decoded PowerShell payload.
3. Review everything done with Domain Admin rights since 10:05:00Z and rotate credentials for privileged accounts that could have been exposed.
4. Block 203.0.113.77 and review other RDP exposure.
