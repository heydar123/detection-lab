# Detection report

Synthetic dataset: 3,061 events, 40 users, 14 days starting 2026-10-01 (seed 7). 6 labeled attack scenarios are hidden in ordinary noise that includes deliberate false-positive sources (a vulnerability scanner, a backup job, a VPN, an approved admin).

## Headline

- Tuned rules: **10 alerts, precision 100%, recall 100%** (10 true positives, 0 false positives).
- Same rules with no exclusions: 40 alerts, precision 25%, recall 100% (30 false positives).

## Per-rule results, before and after tuning

| Rule | Title | Severity | Alerts (untuned) | FP (untuned) | Precision (untuned) | Alerts (tuned) | FP (tuned) | Precision (tuned) | Recall (tuned) |
|---|---|---|---|---|---|---|---|---|---|
| DET-001 | Brute force - many failed logins for one account from one source | medium | 4 | 2 | 50% | 2 | 0 | 100% | 100% |
| DET-002 | Password spray - one source failing against many accounts | high | 3 | 2 | 33% | 1 | 0 | 100% | 100% |
| DET-003 | Impossible travel - successful logins from two countries within an hour | medium | 14 | 11 | 21% | 3 | 0 | 100% | 100% |
| DET-004 | Encoded PowerShell command line | high | 16 | 14 | 12% | 2 | 0 | 100% | 100% |
| DET-005 | Possible account compromise - many failures followed by a success | critical | 1 | 0 | 100% | 1 | 0 | 100% | 100% |
| DET-006 | Privileged group membership change by an unapproved account | critical | 2 | 1 | 50% | 1 | 0 | 100% | 100% |

## MITRE ATT&CK coverage

| Tactic | Technique | Rule | Scenarios detected |
|---|---|---|---|
| Credential Access | T1110.001 Password Guessing | DET-001 | 2/2 |
| Credential Access | T1110.003 Password Spraying | DET-002 | 1/1 |
| Initial Access | T1078 Valid Accounts | DET-003 | 2/2 |
| Execution | T1059.001 PowerShell | DET-004 | 2/2 |
| Credential Access | T1110 Brute Force | DET-005 | 1/1 |
| Persistence | T1098 Account Manipulation | DET-006 | 1/1 |

## Attack scenario outcomes (tuned rules)

| Scenario | Name | Expected rules | Detected | Missed |
|---|---|---|---|---|
| SC-01 | External brute force against a single account | DET-001 | DET-001 | - |
| SC-02 | Password spray across the user base | DET-002 | DET-002 | - |
| SC-03 | Account takeover kill chain | DET-001, DET-005, DET-004, DET-006 | DET-001, DET-005, DET-004, DET-006 | - |
| SC-04 | Impossible travel (US to Romania) | DET-003 | DET-003 | - |
| SC-05 | Office document spawns encoded PowerShell | DET-004 | DET-004 | - |
| SC-06 | Impossible travel (US to Nigeria) | DET-003 | DET-003 | - |

## Remaining false positives after tuning

None. Each exclusion that achieved this is documented in its rule file with a written reason, and should be reviewed regularly.

## Alerts raised (tuned rules)

| Alert | First seen (UTC) | Rule | Severity | Entity | Verdict | Scenario |
|---|---|---|---|---|---|---|
| A-0001 | 2026-10-05T14:00:00Z | DET-001 | medium | src_ip=203.0.113.45, user=j.smith | TP | SC-01 |
| A-0002 | 2026-10-07T03:00:01Z | DET-002 | high | src_ip=203.0.113.99 | TP | SC-02 |
| A-0003 | 2026-10-09T09:30:02Z | DET-001 | medium | src_ip=203.0.113.77, user=d.okafor | TP | SC-03 |
| A-0004 | 2026-10-09T09:30:02Z | DET-005 | critical | user=d.okafor, src_ip=203.0.113.77 | TP | SC-03 |
| A-0005 | 2026-10-09T09:48:00Z | DET-004 | high | user=d.okafor, host=WS-003 | TP | SC-03 |
| A-0006 | 2026-10-09T10:05:00Z | DET-006 | critical | user=d.okafor, target_user=d.okafor, group=Domain Admins | TP | SC-03 |
| A-0007 | 2026-10-12T14:05:00Z | DET-003 | medium | user=r.patel, from=US, to=RO | TP | SC-04 |
| A-0008 | 2026-10-13T15:20:00Z | DET-004 | high | user=k.lee, host=WS-005 | TP | SC-05 |
| A-0009 | 2026-10-14T16:40:00Z | DET-003 | medium | user=s.ivanov, from=US, to=NG | TP | SC-06 |
| A-0010 | 2026-10-14T16:48:00Z | DET-003 | medium | user=s.ivanov, from=NG, to=US | TP | SC-06 |

## False positives before tuning

| Rule | Entity | False-positive alerts |
|---|---|---|
| DET-001 | src_ip=10.0.5.50, user=svc_backup | 2 |
| DET-002 | src_ip=10.0.5.50 | 2 |
| DET-003 | user=m.garcia | 11 |
| DET-004 | user=svc_backup, host=BACKUP-01 | 14 |
| DET-006 | user=it.admin, target_user=svc_patch, group=Administrators | 1 |
