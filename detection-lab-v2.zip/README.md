# detlab - a detection-as-code lab

Six detection rules written as version-controlled YAML, run against a synthetic log dataset that contains
labeled attacks, and scored for **precision and recall**. Every rule has a number you can say out loud.

Everything is fictional: users, hosts, and IPs are invented (IPs are from the RFC 5737 documentation ranges),
and the encoded PowerShell payloads decode to harmless `Write-Output` statements.

## Result (seed 7, 14 days, 3,061 events, 6 hidden attack scenarios)

| | Alerts | True positives | False positives | Precision | Recall |
|---|---|---|---|---|---|
| Rules with no tuning | 40 | 10 | 30 | 25% | 100% |
| Rules with documented exclusions | 10 | 10 | 0 | 100% | 100% |

The interesting part is the first row. The untuned rules catch every attack but drown it in noise: a vulnerability
scanner, a nightly backup job, a corporate VPN, and an approved admin change generate 30 false alerts. Tuning
removed all of them, and each exclusion is written down with a reason in the rule file.

Read `docs/sample-detection-report.md` for the full breakdown and `docs/sample-incident-report.md` for a
worked investigation.

## Quick start

You need Python 3.10 or newer. Running the project needs nothing to install.

```bash
python -m detlab run                           # generate data, detect, score, write build/detection_report.md
python -m detlab validate                      # lint the rules
python -m detlab case --user d.okafor          # incident timeline for one account
```

To run the tests, install pytest first:

```bash
pip install -r requirements.txt
python -m pytest -q                            # 44 tests
```

On Mac or Linux, use `python3` instead of `python`. PyYAML's pure-Python code is bundled in `detlab/_vendor`
(MIT license included), so there is nothing to compile. The project was run on Python 3.11 through 3.15. If PyYAML is
installed, it is used instead of the bundled copy.

Other commands: `generate` (dataset only), `detect` (rules over an existing dataset; `--no-exclusions` shows the
untuned noise).

## What is in the lab

| Rule | Detects | ATT&CK | Type |
|---|---|---|---|
| DET-001 | 20+ failed logins, one account, one source, 5 min | T1110.001 Password Guessing | threshold |
| DET-002 | One source failing against 10+ accounts in 30 min | T1110.003 Password Spraying | distinct count |
| DET-003 | Successful logins from two countries within 60 min | T1078 Valid Accounts | impossible travel |
| DET-004 | PowerShell with an encoded command | T1059.001 PowerShell | match (regex) |
| DET-005 | 10+ failures then a success, same account and source | T1110 Brute Force | sequence |
| DET-006 | Privileged group change by an unapproved account | T1098 Account Manipulation | match |

Every rule file contains the logic, the ATT&CK mapping, known false positives, triage questions, response
steps, and draft Microsoft Sentinel (KQL) and Splunk (SPL) translations.

```
rules/        detection rules (YAML) - the product
detlab/       rule loader and validator, engine, log generator, scorer, report writer
tests/        44 tests: matching, each rule type, validation, and end-to-end scoring
docs/         sample outputs and a guide to presenting this project
```

## How it works

1. **Generate.** `generate.py` builds 14 days of normal activity for 40 users, adds deliberate false-positive
   sources, and hides six labeled attack scenarios, including a full kill chain: brute force, successful RDP login,
   encoded PowerShell, then self-added to Domain Admins. The seed makes it reproducible.
2. **Detect.** `engine.py` runs each YAML rule over the time-sorted events. Rules never see the ground truth.
3. **Score.** `evaluate.py` compares alerts to the labeled events. An alert whose evidence contains no malicious
   event is a false positive; a scenario with no alert from an expected rule is a miss.
4. **Tune.** Exclusions live in the rule file and must include a written reason. The validator rejects any
   exclusion without one, so the suppressions stay auditable.
5. **Test.** Tests pin the behavior: every attack is caught across five different random seeds, no false positives
   remain after tuning, and the backup-job exclusion is pinned to user *and* host so it cannot hide the same
   command elsewhere.

## Limitations (read before you quote the numbers)

- **The data is synthetic and the rules were tuned to it.** 100% recall and precision here show the method works.
  They say nothing about how these rules would perform in a real environment. Do not present them as production results.
- **Exclusions are a tradeoff.** Excluding `it.admin` from DET-006 silences a noisy source but blinds the rule if
  that account is compromised. The rule file says so and proposes a compensating alert.
- **The KQL and SPL are untested drafts.** Field names differ between environments. Run them in a real Sentinel
  or Splunk instance before relying on them.
- **No alert correlation.** One incident can raise several alerts (DET-003 raises one alert out and one back for the
  same user). Grouping alerts into cases is the next step.
- **Scoring is generous in one place.** An alert counts as a true positive if its evidence includes at least one
  malicious event, even if it also includes benign ones.

## Ideas to extend it

- Add a rule for discovery commands (`whoami /all`) following encoded PowerShell. SC-05 contains one that no rule covers.
- Replay a public attack dataset (for example OTRF Security-Datasets or Splunk attack_data) through the engine.
- Export rules to Sigma format so they run on other platforms.
- Group alerts into cases by user and host, and score case-level detection time.
- Run the KQL drafts in a free Microsoft Sentinel or Splunk instance and record what you had to change.
