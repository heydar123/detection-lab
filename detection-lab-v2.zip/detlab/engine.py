"""Detection engine: runs YAML rules over a list of events and returns alerts.

Events must already carry the parsed epoch time in ``_t`` (see
``models.prepare_events``). Every rule type works on a time-sorted stream.
Rule exclusions are applied up front, so a documented exclusion removes those
events from that rule only.
"""

from __future__ import annotations

from collections import defaultdict, deque

from .matching import excluded, matches
from .models import Alert


def _entity(ev: dict, fields: list[str]) -> dict:
    return {f: ev.get(f) for f in fields}


def _new_alert(rule: dict, entity: dict, evs: list[dict]) -> Alert:
    return Alert(
        rule_id=rule["id"],
        title=rule["title"],
        severity=rule["severity"],
        tactic=rule["attack"]["tactic"],
        technique=rule["attack"]["technique"],
        entity=entity,
        first_t=evs[0]["_t"],
        last_t=evs[-1]["_t"],
        event_ids=[e["event_id"] for e in evs],
    )


def _fmt_entity(entity: dict) -> str:
    return ", ".join(f"{k}={v}" for k, v in entity.items())


# ---------------------------------------------------------------- rule types

def run_match(rule: dict, events: list[dict]) -> list[Alert]:
    """One alert per event that satisfies the filter."""
    alerts = []
    for ev in events:
        if matches(ev, rule["filter"]):
            entity = _entity(ev, rule["entity_fields"])
            alert = _new_alert(rule, entity, [ev])
            alert.summary = f"{rule['title']} ({_fmt_entity(entity)})"
            alerts.append(alert)
    return alerts


def run_threshold(rule: dict, events: list[dict]) -> list[Alert]:
    """N matching events for the same group inside a sliding window.

    Once an alert is open, further matching events inside the window extend it
    rather than creating a new alert for every event.
    """
    window, threshold = rule["window_seconds"], rule["threshold"]
    buckets: dict[tuple, deque] = defaultdict(deque)
    open_alert: dict[tuple, Alert] = {}
    alerts: list[Alert] = []

    for ev in events:
        if not matches(ev, rule["filter"]):
            continue
        key = tuple(ev.get(f) for f in rule["group_by"])
        dq = buckets[key]
        dq.append(ev)
        while dq and ev["_t"] - dq[0]["_t"] > window:
            dq.popleft()

        current = open_alert.get(key)
        if current and ev["_t"] - current.last_t <= window:
            current.event_ids.append(ev["event_id"])
            current.last_t = ev["_t"]
        elif len(dq) >= threshold:
            alert = _new_alert(rule, _entity(ev, rule["group_by"]), list(dq))
            open_alert[key] = alert
            alerts.append(alert)

    for a in alerts:
        a.summary = (f"{len(a.event_ids)} matching events over {int(a.last_t - a.first_t)}s "
                     f"({_fmt_entity(a.entity)})")
    return alerts


def run_distinct_threshold(rule: dict, events: list[dict]) -> list[Alert]:
    """N distinct values of one field (e.g. usernames) from the same group in a window."""
    window, threshold, dfield = rule["window_seconds"], rule["threshold"], rule["distinct_field"]
    buckets: dict[tuple, deque] = defaultdict(deque)
    open_alert: dict[tuple, Alert] = {}
    alerts: list[Alert] = []
    distinct_seen: dict[int, set] = {}

    for ev in events:
        if not matches(ev, rule["filter"]):
            continue
        key = tuple(ev.get(f) for f in rule["group_by"])
        dq = buckets[key]
        dq.append(ev)
        while dq and ev["_t"] - dq[0]["_t"] > window:
            dq.popleft()

        current = open_alert.get(key)
        if current and ev["_t"] - current.last_t <= window:
            current.event_ids.append(ev["event_id"])
            current.last_t = ev["_t"]
            distinct_seen[id(current)].add(ev.get(dfield))
        elif len({e.get(dfield) for e in dq}) >= threshold:
            alert = _new_alert(rule, _entity(ev, rule["group_by"]), list(dq))
            open_alert[key] = alert
            distinct_seen[id(alert)] = {e.get(dfield) for e in dq}
            alerts.append(alert)

    for a in alerts:
        n = len(distinct_seen[id(a)])
        a.summary = (f"{n} distinct {dfield} values, {len(a.event_ids)} events over "
                     f"{int(a.last_t - a.first_t)}s ({_fmt_entity(a.entity)})")
    return alerts


def run_impossible_travel(rule: dict, events: list[dict]) -> list[Alert]:
    """Successful logins for one user from two countries within max_minutes."""
    limit = rule["max_minutes"] * 60
    last: dict[str, dict] = {}
    alerts: list[Alert] = []
    for ev in events:
        if not matches(ev, rule["filter"]):
            continue
        user, prev = ev.get("user"), last.get(ev.get("user"))
        if prev and prev.get("country") != ev.get("country") and ev["_t"] - prev["_t"] <= limit:
            entity = {"user": user, "from": prev.get("country"), "to": ev.get("country")}
            alert = _new_alert(rule, entity, [prev, ev])
            gap = int((ev["_t"] - prev["_t"]) // 60)
            alert.summary = (f"{user} logged in from {prev.get('country')} then {ev.get('country')} "
                             f"{gap} min apart")
            alerts.append(alert)
        last[user] = ev
    return alerts


def run_fail_then_success(rule: dict, events: list[dict]) -> list[Alert]:
    """min_failures failed logins followed by a success, same group, inside a window."""
    window, minimum = rule["window_seconds"], rule["min_failures"]
    fails: dict[tuple, deque] = defaultdict(deque)
    alerts: list[Alert] = []
    for ev in events:
        key = tuple(ev.get(f) for f in rule["group_by"])
        if matches(ev, rule["failure_filter"]):
            dq = fails[key]
            dq.append(ev)
            while dq and ev["_t"] - dq[0]["_t"] > window:
                dq.popleft()
        elif matches(ev, rule["success_filter"]):
            dq = fails.get(key)
            if not dq:
                continue
            while dq and ev["_t"] - dq[0]["_t"] > window:
                dq.popleft()
            if len(dq) >= minimum:
                alert = _new_alert(rule, _entity(ev, rule["group_by"]), list(dq) + [ev])
                alert.summary = (f"{len(dq)} failures then a success within {window}s "
                                 f"({_fmt_entity(alert.entity)})")
                alerts.append(alert)
                dq.clear()
    return alerts


RUNNERS = {
    "match": run_match,
    "threshold": run_threshold,
    "distinct_threshold": run_distinct_threshold,
    "impossible_travel": run_impossible_travel,
    "fail_then_success": run_fail_then_success,
}


def run_rules(events: list[dict], rules: list[dict], use_exclusions: bool = True) -> list[Alert]:
    """Run every rule and return alerts ordered by time, with stable alert IDs."""
    ordered = sorted(events, key=lambda e: (e["_t"], e["event_id"]))
    alerts: list[Alert] = []
    for rule in rules:
        stream = ordered
        if use_exclusions and rule.get("exclusions"):
            stream = [e for e in ordered if not excluded(e, rule["exclusions"])]
        alerts.extend(RUNNERS[rule["type"]](rule, stream))
    alerts.sort(key=lambda a: (a.first_t, a.rule_id))
    for i, alert in enumerate(alerts, start=1):
        alert.alert_id = f"A-{i:04d}"
    return alerts
