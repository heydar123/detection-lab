"""Loading and validating detection rules (the 'lint' step of detection-as-code)."""

from __future__ import annotations

import re
from pathlib import Path

try:
    import yaml
except ImportError:
    # PyYAML is not installed (for example on a very new Python that has no prebuilt PyYAML
    # yet). Use the bundled pure-Python copy so the project runs with nothing to install.
    from ._vendor import yaml

from .matching import validate_filter
from .models import SEVERITY_ORDER

RULE_TYPES = {
    "match": ["filter"],
    "threshold": ["filter", "group_by", "window_seconds", "threshold"],
    "distinct_threshold": ["filter", "group_by", "distinct_field", "window_seconds", "threshold"],
    "impossible_travel": ["filter", "max_minutes"],
    "fail_then_success": ["failure_filter", "success_filter", "group_by", "window_seconds", "min_failures"],
}
COMMON_REQUIRED = ["id", "title", "status", "severity", "attack", "description", "type", "triage", "response"]
ID_RE = re.compile(r"^DET-\d{3}$")
TECHNIQUE_RE = re.compile(r"^T\d{4}(\.\d{3})?$")
POSITIVE_INT_KEYS = ["window_seconds", "threshold", "max_minutes", "min_failures"]


def load_rules(path: str | Path) -> list[dict]:
    """Load every *.yml rule in a directory (or a single file), sorted by id."""
    p = Path(path)
    files = sorted(p.glob("*.yml")) if p.is_dir() else [p]
    rules = []
    for f in files:
        with open(f, encoding="utf-8") as fh:
            rule = yaml.safe_load(fh)
        rule["_file"] = f.name
        rules.append(rule)
    return sorted(rules, key=lambda r: r.get("id", ""))


def validate_rule(rule: dict) -> list[str]:
    errors: list[str] = []
    name = rule.get("_file", rule.get("id", "<rule>"))

    for key in COMMON_REQUIRED:
        if key not in rule:
            errors.append(f"{name}: missing required key '{key}'")
    if errors:
        return errors

    if not ID_RE.match(str(rule["id"])):
        errors.append(f"{name}: id must look like DET-001")
    if rule["severity"] not in SEVERITY_ORDER:
        errors.append(f"{name}: severity must be one of {sorted(SEVERITY_ORDER)}")
    attack = rule["attack"]
    for key in ("tactic", "technique", "technique_name"):
        if key not in attack:
            errors.append(f"{name}: attack.{key} is required")
    if "technique" in attack and not TECHNIQUE_RE.match(str(attack["technique"])):
        errors.append(f"{name}: attack.technique must look like T1110 or T1110.001")
    for key in ("triage", "response"):
        steps = rule[key]
        if not isinstance(steps, list) or not steps:
            errors.append(f"{name}: {key} must be a non-empty list of steps")
        elif not all(isinstance(s, str) for s in steps):
            errors.append(f"{name}: every {key} step must be plain text "
                          "(a step containing ': ' must be quoted in YAML or it parses as a mapping)")

    rtype = rule["type"]
    if rtype not in RULE_TYPES:
        errors.append(f"{name}: unknown type {rtype!r} (valid: {sorted(RULE_TYPES)})")
        return errors
    for key in RULE_TYPES[rtype]:
        if key not in rule:
            errors.append(f"{name}: type '{rtype}' requires '{key}'")
    for key in POSITIVE_INT_KEYS:
        if key in rule and (not isinstance(rule[key], int) or rule[key] <= 0):
            errors.append(f"{name}: {key} must be a positive integer")
    for key in ("filter", "failure_filter", "success_filter"):
        if key in rule:
            errors.extend(validate_filter(rule[key], f"{name}.{key}"))
    if rtype == "match" and "entity_fields" not in rule:
        errors.append(f"{name}: match rules need 'entity_fields' so alerts identify who/what")

    for i, ex in enumerate(rule.get("exclusions", []) or []):
        if "match" not in ex or "reason" not in ex or not str(ex["reason"]).strip():
            errors.append(f"{name}: exclusion #{i + 1} needs both 'match' and a written 'reason'")
        else:
            errors.extend(validate_filter(ex["match"], f"{name}.exclusions[{i}]"))
    return errors


def validate_rules(rules: list[dict]) -> list[str]:
    errors: list[str] = []
    seen: dict[str, str] = {}
    for rule in rules:
        errors.extend(validate_rule(rule))
        rid = rule.get("id")
        if rid in seen:
            errors.append(f"{rule.get('_file')}: duplicate id {rid} (also in {seen[rid]})")
        elif rid:
            seen[rid] = rule.get("_file", "?")
    return errors
