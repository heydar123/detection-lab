"""Markdown output: detection report and per-user incident case file."""

from __future__ import annotations

from collections import Counter, defaultdict

from .models import SEVERITY_ORDER, Alert, fmt_ts


def _pct(x) -> str:
    return "n/a" if x is None else f"{x * 100:.0f}%"


def _table(headers: list[str], rows: list[list]) -> str:
    out = ["| " + " | ".join(headers) + " |", "|" + "|".join("---" for _ in headers) + "|"]
    for row in rows:
        out.append("| " + " | ".join(str(c) for c in row) + " |")
    return "\n".join(out)


def _fmt_entity(entity: dict) -> str:
    return ", ".join(f"{k}={v}" for k, v in entity.items())


def render_report(rules: list[dict], alerts: list[Alert], truth: dict, tuned: dict, untuned: dict) -> str:
    meta = truth["meta"]
    lines = [
        "# Detection report",
        "",
        f"Synthetic dataset: {meta['events']:,} events, {meta['users']} users, {meta['days']} days "
        f"starting {meta['start']} (seed {meta['seed']}). {len(truth['scenarios'])} labeled attack scenarios "
        "are hidden in ordinary noise that includes deliberate false-positive sources "
        "(a vulnerability scanner, a backup job, a VPN, an approved admin).",
        "",
        "## Headline",
        "",
    ]
    t, u = tuned["overall"], untuned["overall"]
    lines += [
        f"- Tuned rules: **{t['alerts']} alerts, precision {_pct(t['precision'])}, recall {_pct(t['recall'])}** "
        f"({t['tp']} true positives, {t['fp']} false positives).",
        f"- Same rules with no exclusions: {u['alerts']} alerts, precision {_pct(u['precision'])}, "
        f"recall {_pct(u['recall'])} ({u['fp']} false positives).",
        "",
        "## Per-rule results, before and after tuning",
        "",
    ]
    rows = []
    for r in rules:
        rid = r["id"]
        a, b = untuned["per_rule"][rid], tuned["per_rule"][rid]
        rows.append([rid, r["title"], r["severity"], a["alerts"], a["fp"], _pct(a["precision"]),
                     b["alerts"], b["fp"], _pct(b["precision"]), _pct(b["recall"])])
    lines.append(_table(
        ["Rule", "Title", "Severity", "Alerts (untuned)", "FP (untuned)", "Precision (untuned)",
         "Alerts (tuned)", "FP (tuned)", "Precision (tuned)", "Recall (tuned)"], rows))

    lines += ["", "## MITRE ATT&CK coverage", ""]
    lines.append(_table(
        ["Tactic", "Technique", "Rule", "Scenarios detected"],
        [[r["attack"]["tactic"], f"{r['attack']['technique']} {r['attack']['technique_name']}", r["id"],
          f"{tuned['per_rule'][r['id']]['detected']}/{tuned['per_rule'][r['id']]['expected']}"] for r in rules]))

    lines += ["", "## Attack scenario outcomes (tuned rules)", ""]
    rows = []
    for sc, res in tuned["scenarios"].items():
        rows.append([sc, res["name"], ", ".join(res["expected"]), ", ".join(res["detected"]) or "-",
                     ", ".join(res["missed"]) or "-"])
    lines.append(_table(["Scenario", "Name", "Expected rules", "Detected", "Missed"], rows))

    lines += ["", "## Remaining false positives after tuning", ""]
    groups: Counter = Counter()
    for a in alerts:
        v = tuned["verdicts"].get(a.alert_id)
        if v and v["verdict"] == "FP":
            groups[(a.rule_id, _fmt_entity(a.entity))] += 1
    if groups:
        lines.append(_table(["Rule", "Entity", "Count"], [[k[0], k[1], n] for k, n in groups.most_common()]))
    else:
        lines.append("None. Each exclusion that achieved this is documented in its rule file with a written "
                     "reason, and should be reviewed regularly.")

    lines += ["", "## Alerts raised (tuned rules)", ""]
    rows = []
    for a in alerts:
        v = tuned["verdicts"][a.alert_id]
        rows.append([a.alert_id, a.first_ts, a.rule_id, a.severity, _fmt_entity(a.entity), v["verdict"],
                     ", ".join(v["scenarios"]) or "-"])
    lines.append(_table(["Alert", "First seen (UTC)", "Rule", "Severity", "Entity", "Verdict", "Scenario"], rows))
    lines.append("")
    return "\n".join(lines)


def render_untuned_fp_table(untuned_alerts: list[Alert], untuned: dict) -> str:
    groups: Counter = Counter()
    for a in untuned_alerts:
        if untuned["verdicts"][a.alert_id]["verdict"] == "FP":
            entity = dict(a.entity)
            if a.rule_id == "DET-003":
                entity = {"user": entity.get("user")}
            groups[(a.rule_id, _fmt_entity(entity))] += 1
    rows = [[k[0], k[1], n] for k, n in sorted(groups.items())]
    return _table(["Rule", "Entity", "False-positive alerts"], rows)


# ------------------------------------------------------------------ case file

def _describe(ev: dict) -> str:
    if ev["action"] == "login":
        return (f"{ev['outcome']} {ev['service']} login for `{ev['user']}` from {ev['src_ip']} ({ev['country']})")
    if ev["action"] == "process_create":
        cmd = ev["command_line"]
        cmd = cmd if len(cmd) <= 110 else cmd[:110] + "..."
        return f"`{ev['process_name']}` started on {ev['host']} by `{ev['user']}` (parent `{ev['parent_process']}`): `{cmd}`"
    if ev["action"] == "group_add":
        return f"`{ev['user']}` added `{ev['target_user']}` to **{ev['group']}** on {ev['host']}"
    return ev["action"]


def render_case(user: str, events: list[dict], alerts: list[Alert], rules: list[dict]) -> str:
    by_id = {e["event_id"]: e for e in events}
    rule_by_id = {r["id"]: r for r in rules}

    def involves(a: Alert) -> bool:
        for eid in a.event_ids:
            ev = by_id.get(eid, {})
            if user in (ev.get("user"), ev.get("target_user")):
                return True
        return False

    mine = [a for a in alerts if involves(a)]
    if not mine:
        return f"# Incident case: {user}\n\nNo alerts involve this user.\n"

    start = min(a.first_t for a in mine) - 1800
    end = max(a.last_t for a in mine) + 1800
    cited = defaultdict(list)
    for a in mine:
        for eid in a.event_ids:
            cited[eid].append(a.alert_id)

    window = [e for e in events if start <= e["_t"] <= end and
              (e.get("user") == user or e.get("target_user") == user)]

    # collapse runs of failed logins from the same source into one timeline row
    rows: list[list] = []
    i = 0
    while i < len(window):
        ev = window[i]
        if ev["action"] == "login" and ev["outcome"] == "failure":
            j = i
            while (j + 1 < len(window) and window[j + 1]["action"] == "login"
                   and window[j + 1]["outcome"] == "failure" and window[j + 1]["src_ip"] == ev["src_ip"]):
                j += 1
            run = window[i:j + 1]
            refs = sorted({r for e in run for r in cited.get(e["event_id"], [])})
            rows.append([run[0]["ts"], f"{len(run)} failed {ev['service']} logins for `{user}` from "
                         f"{ev['src_ip']} ({ev['country']}), last at {run[-1]['ts'][11:19]}Z", ", ".join(refs) or "-"])
            i = j + 1
            continue
        rows.append([ev["ts"], _describe(ev), ", ".join(cited.get(ev["event_id"], [])) or "-"])
        i += 1

    sev = max(mine, key=lambda a: SEVERITY_ORDER[a.severity]).severity
    tactics = []
    for a in sorted(mine, key=lambda a: a.first_t):
        if a.tactic not in tactics:
            tactics.append(a.tactic)

    seen = set()
    triage, response = [], []
    for a in mine:
        if a.rule_id in seen:
            continue
        seen.add(a.rule_id)
        rule = rule_by_id[a.rule_id]
        triage += [f"{rule['id']}: {s}" for s in rule["triage"]]
        response += [f"{rule['id']}: {s}" for s in rule["response"]]

    lines = [
        f"# Incident case file: `{user}`",
        "",
        "_Generated from synthetic lab data by detlab. Every name, IP, and host in this file is fictional._",
        "",
        "## Summary",
        "",
        f"- Highest severity: **{sev}**",
        f"- Alerts involving this account: {len(mine)} across {len(seen)} detection rules",
        f"- Observed tactic sequence: {' -> '.join(tactics)}",
        f"- Window: {fmt_ts(start + 1800)} to {fmt_ts(end - 1800)} (UTC)",
        "",
        "## Alerts",
        "",
        _table(["Alert", "Time (UTC)", "Rule", "Severity", "ATT&CK", "What fired"],
               [[a.alert_id, a.first_ts, a.rule_id, a.severity, a.technique, a.summary]
                for a in sorted(mine, key=lambda a: a.first_t)]),
        "",
        "## Timeline",
        "",
        _table(["Time (UTC)", "Event", "Alert"], rows),
        "",
        "## Triage questions",
        "",
        *[f"- {s}" for s in triage],
        "",
        "## Recommended response",
        "",
        *[f"- {s}" for s in response],
        "",
    ]
    return "\n".join(lines)
