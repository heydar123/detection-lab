"""Command line interface: python -m detlab <command>."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from .engine import run_rules
from .evaluate import evaluate
from .generate import MIN_DAYS, generate, write_dataset
from .models import Alert, load_events, prepare_events, read_jsonl, write_jsonl
from .report import _pct, render_case, render_report, render_untuned_fp_table
from .rules import load_rules, validate_rules


def _summary_table(rules: list[dict], result: dict) -> str:
    head = f"{'Rule':<8} {'Alerts':>6} {'TP':>4} {'FP':>4} {'Precision':>10} {'Recall':>8}  Title"
    lines = [head, "-" * len(head)]
    for r in rules:
        row = result["per_rule"][r["id"]]
        lines.append(f"{r['id']:<8} {row['alerts']:>6} {row['tp']:>4} {row['fp']:>4} "
                     f"{_pct(row['precision']):>10} {_pct(row['recall']):>8}  {r['title']}")
    o = result["overall"]
    lines.append("-" * len(head))
    lines.append(f"{'ALL':<8} {o['alerts']:>6} {o['tp']:>4} {o['fp']:>4} "
                 f"{_pct(o['precision']):>10} {_pct(o['recall']):>8}")
    return "\n".join(lines)


def cmd_validate(args) -> int:
    rules = load_rules(args.rules)
    errors = validate_rules(rules)
    if errors:
        print("Rule validation FAILED:")
        for e in errors:
            print(f"  - {e}")
        return 1
    print(f"OK: {len(rules)} rules valid")
    return 0


def cmd_generate(args) -> int:
    events, truth = generate(args.seed, args.days)
    write_dataset(events, truth, args.out)
    print(f"Wrote {len(events)} events and ground truth to {args.out}/")
    return 0


def cmd_detect(args) -> int:
    rules = load_rules(args.rules)
    errors = validate_rules(rules)
    if errors:
        print("\n".join(errors))
        return 1
    events = load_events(Path(args.data) / "events.jsonl")
    alerts = run_rules(events, rules, use_exclusions=not args.no_exclusions)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    write_jsonl(out / "alerts.jsonl", [a.to_dict() for a in alerts])
    print(f"{len(alerts)} alerts written to {out / 'alerts.jsonl'}")
    truth_path = Path(args.data) / "ground_truth.json"
    if truth_path.exists():
        truth = json.loads(truth_path.read_text())
        print()
        print(_summary_table(rules, evaluate(alerts, truth, rules)))
    return 0


def cmd_run(args) -> int:
    rules = load_rules(args.rules)
    errors = validate_rules(rules)
    if errors:
        print("Rule validation FAILED:\n  " + "\n  ".join(errors))
        return 1

    events, truth = generate(args.seed, args.days)
    out = Path(args.out)
    write_dataset(events, truth, out)
    prepare_events(events)

    tuned_alerts = run_rules(events, rules, use_exclusions=True)
    untuned_alerts = run_rules(events, rules, use_exclusions=False)
    tuned = evaluate(tuned_alerts, truth, rules)
    untuned = evaluate(untuned_alerts, truth, rules)

    write_jsonl(out / "alerts.jsonl", [a.to_dict() for a in tuned_alerts])
    write_jsonl(out / "alerts_untuned.jsonl", [a.to_dict() for a in untuned_alerts])

    report = render_report(rules, tuned_alerts, truth, tuned, untuned)
    report += "\n## False positives before tuning\n\n" + render_untuned_fp_table(untuned_alerts, untuned) + "\n"
    (out / "detection_report.md").write_text(report, encoding="utf-8")

    print(f"Generated {len(events)} events ({args.days} days, seed {args.seed})\n")
    print("WITHOUT tuning (no exclusions):")
    print(_summary_table(rules, untuned))
    print("\nWITH tuning (documented exclusions applied):")
    print(_summary_table(rules, tuned))
    print(f"\nReport: {out / 'detection_report.md'}")
    return 0


def cmd_case(args) -> int:
    data = Path(args.data)
    events = load_events(data / "events.jsonl")
    alerts = [Alert.from_dict(d) for d in read_jsonl(data / "alerts.jsonl")]
    rules = load_rules(args.rules)
    text = render_case(args.user, events, alerts, rules)
    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
        print(f"Case file written to {args.out}")
    else:
        print(text)
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="detlab", description="Detection-as-code lab")
    sub = p.add_subparsers(dest="command", required=True)

    v = sub.add_parser("validate", help="lint the rule files")
    v.add_argument("--rules", default="rules")
    v.set_defaults(func=cmd_validate)

    g = sub.add_parser("generate", help="generate a synthetic dataset")
    g.add_argument("--out", default="build")
    g.add_argument("--seed", type=int, default=7)
    g.add_argument("--days", type=int, default=MIN_DAYS)
    g.set_defaults(func=cmd_generate)

    d = sub.add_parser("detect", help="run rules over an existing dataset")
    d.add_argument("--data", default="build")
    d.add_argument("--rules", default="rules")
    d.add_argument("--out", default="build")
    d.add_argument("--no-exclusions", action="store_true", help="ignore documented exclusions")
    d.set_defaults(func=cmd_detect)

    r = sub.add_parser("run", help="generate, detect, score, and write the report")
    r.add_argument("--out", default="build")
    r.add_argument("--rules", default="rules")
    r.add_argument("--seed", type=int, default=7)
    r.add_argument("--days", type=int, default=MIN_DAYS)
    r.set_defaults(func=cmd_run)

    c = sub.add_parser("case", help="build an incident case file for one user")
    c.add_argument("--user", required=True)
    c.add_argument("--data", default="build")
    c.add_argument("--rules", default="rules")
    c.add_argument("--out", help="write markdown here instead of stdout")
    c.set_defaults(func=cmd_case)
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
