"""Synthetic log generator with labeled attack scenarios.

Everything here is fake: IPs come from the RFC 5737 documentation ranges, users
are invented, and the "encoded PowerShell" payloads decode to harmless echo
statements. The generator is seeded, so the same seed always produces the same
dataset, which makes detection results reproducible.

Ground truth is kept in a separate file (event IDs per attack scenario plus the
rules each scenario is expected to trigger). Detection rules never see it.
"""

from __future__ import annotations

import base64
import json
import random
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .models import fmt_ts

START = datetime(2026, 10, 1, tzinfo=timezone.utc)  # a Thursday
MIN_DAYS = 14
N_USERS = 40

SCANNER_IP = "10.0.5.50"       # approved vulnerability scanner (benign noise)
VPN_EGRESS_IP = "192.0.2.77"   # corporate VPN exit node in the Netherlands (benign noise)
BACKUP_HOST = "BACKUP-01"

NAMED_USERS = ["a.nguyen", "j.smith", "d.okafor", "r.patel", "k.lee", "m.garcia", "s.ivanov", "t.brown"]
FIRST_INITIALS = list("bcefghlnoprvw")
LAST_NAMES = ["silva", "chen", "khan", "rossi", "novak", "larsen", "murphy", "cohen", "dubois", "sato",
              "reyes", "walker", "hughes", "moreau", "adams", "fischer", "kowalski", "mendez", "yamada",
              "oneill", "castro", "baker", "ortiz", "lindgren"]

BENIGN_PROCESSES = [
    ("chrome.exe", "explorer.exe", "chrome.exe --profile-directory=Default"),
    ("excel.exe", "explorer.exe", "EXCEL.EXE /e"),
    ("powershell.exe", "explorer.exe", "powershell.exe -NoProfile -Command Get-Process"),
    ("powershell.exe", "explorer.exe", "powershell.exe -ExecutionPolicy Bypass -File C:\\IT\\inventory.ps1"),
    ("cmd.exe", "explorer.exe", "cmd.exe /c ipconfig /all"),
    ("teams.exe", "explorer.exe", "Teams.exe --process-start-args"),
]

SCENARIOS = {
    "SC-01": {
        "name": "External brute force against a single account",
        "description": "120 failed RDP logins against j.smith from one external IP in about 4 minutes. No success.",
        "expected_rules": ["DET-001"],
    },
    "SC-02": {
        "name": "Password spray across the user base",
        "description": "One external IP tries two passwords against 30 accounts over 40 minutes; one weak password works.",
        "expected_rules": ["DET-002"],
    },
    "SC-03": {
        "name": "Account takeover kill chain",
        "description": ("Brute force on d.okafor succeeds over RDP, followed by encoded PowerShell on the user's "
                        "workstation and the account adding itself to Domain Admins."),
        "expected_rules": ["DET-001", "DET-005", "DET-004", "DET-006"],
    },
    "SC-04": {
        "name": "Impossible travel (US to Romania)",
        "description": "r.patel logs in from the US, then from Romania 17 minutes later.",
        "expected_rules": ["DET-003"],
    },
    "SC-05": {
        "name": "Office document spawns encoded PowerShell",
        "description": "winword.exe launches a hidden, encoded PowerShell command on k.lee's workstation, then runs whoami.",
        "expected_rules": ["DET-004"],
    },
    "SC-06": {
        "name": "Impossible travel (US to Nigeria)",
        "description": "s.ivanov logs in from the US, then from Nigeria 8 minutes later.",
        "expected_rules": ["DET-003"],
    },
}


def enc_ps(command: str) -> str:
    """PowerShell -EncodedCommand format: base64 of UTF-16LE text."""
    return base64.b64encode(command.encode("utf-16-le")).decode("ascii")


def _make_users(rng: random.Random) -> list[dict]:
    names = list(NAMED_USERS)
    seen = set(names)
    while len(names) < N_USERS:
        candidate = f"{rng.choice(FIRST_INITIALS)}.{rng.choice(LAST_NAMES)}"
        if candidate not in seen:
            seen.add(candidate)
            names.append(candidate)
    octets = list(range(10, 250))
    rng.shuffle(octets)
    return [
        {"name": n, "ip": f"198.51.100.{octets[i]}", "host": f"WS-{i + 1:03d}", "country": "US"}
        for i, n in enumerate(names)
    ]


def generate(seed: int = 7, days: int = MIN_DAYS) -> tuple[list[dict], dict]:
    """Return (events, ground_truth). Events are sorted and have event IDs."""
    if days < MIN_DAYS:
        raise ValueError(f"days must be at least {MIN_DAYS} so every attack scenario fits")

    rng = random.Random(seed)
    users = _make_users(rng)
    by_name = {u["name"]: u for u in users}
    raw: list[dict] = []

    def at(day: int, hour: int = 0, minute: int = 0, second: int = 0) -> datetime:
        return START + timedelta(days=day, hours=hour, minutes=minute, seconds=second)

    def emit(t: datetime, sc: str | None, **fields) -> None:
        raw.append({"_t": t, "_sc": sc, **fields})

    def login(t, user, ip, country, outcome, service, sc=None):
        emit(t, sc, category="authentication", action="login", outcome=outcome, user=user,
             src_ip=ip, country=country, service=service, host="auth-gw")

    def proc(t, user, host, name, parent, cmd, sc=None):
        emit(t, sc, category="process", action="process_create", user=user, host=host,
             process_name=name, parent_process=parent, command_line=cmd)

    def group_add(t, actor, target, group, host, sc=None):
        emit(t, sc, category="iam", action="group_add", user=actor, target_user=target,
             group=group, host=host)

    # ------------------------------------------------------------ benign noise
    for day in range(days):
        weekend = at(day).weekday() >= 5
        for u in users:
            if u["name"] == "t.brown" and day == 7:
                continue  # travelling: handled explicitly below
            if weekend and rng.random() > 0.15:
                continue
            for _ in range(rng.randint(1, 2)):
                t = at(day) + timedelta(seconds=rng.randint(12 * 3600, 22 * 3600))
                service = rng.choices(["o365", "rdp", "ssh"], weights=[60, 25, 15])[0]
                if rng.random() < 0.06:  # ordinary typo before a successful login
                    typos = rng.randint(1, 2)
                    for i in range(typos):
                        login(t - timedelta(seconds=(typos - i) * rng.randint(5, 20)),
                              u["name"], u["ip"], u["country"], "failure", service)
                login(t, u["name"], u["ip"], u["country"], "success", service)
            for _ in range(rng.randint(3, 6)):
                t = at(day) + timedelta(seconds=rng.randint(12 * 3600, 22 * 3600))
                name, parent, cmd = rng.choice(BENIGN_PROCESSES)
                proc(t, u["name"], u["host"], name, parent, cmd)

    # Nightly backup job runs an encoded PowerShell command (false-positive source for DET-004).
    backup_cmd = f"powershell.exe -NoProfile -EncodedCommand {enc_ps('Start-Backup -Target D:')}"
    for day in range(days):
        login(at(day, 3, 0), "svc_backup", "10.0.8.10", "US", "success", "ssh")
        proc(at(day, 3, 5), "svc_backup", BACKUP_HOST, "powershell.exe", "taskeng.exe", backup_cmd)

    # Weekly vulnerability scan makes failed logins against everyone (FP source for DET-001, DET-002).
    for day in (5, 11):
        k = 0
        t0 = at(day, 2, 0)
        for u in users:
            for _ in range(2):
                login(t0 + timedelta(seconds=k * 3), u["name"], SCANNER_IP, "US", "failure", "ssh")
                k += 1
        for j in range(30):
            login(t0 + timedelta(seconds=k * 3 + j * 4), "svc_backup", SCANNER_IP, "US", "failure", "ssh")

    # VPN user: US login, then a login that exits via the Netherlands (FP source for DET-003).
    for day in range(days):
        if at(day).weekday() < 5:
            t = at(day, 14, 0) + timedelta(seconds=rng.randint(0, 1800))
            login(t, "m.garcia", by_name["m.garcia"]["ip"], "US", "success", "o365")
            login(t + timedelta(minutes=10), "m.garcia", VPN_EGRESS_IP, "NL", "success", "vpn")

    # Genuine traveller: US one day, UK the next day. Hours apart, so not impossible travel.
    login(at(6, 21, 30), "t.brown", by_name["t.brown"]["ip"], "US", "success", "o365")
    login(at(7, 20, 0), "t.brown", "192.0.2.150", "GB", "success", "o365")

    # Approved admin change (FP source for DET-006), plus an unrelated group change.
    group_add(at(7, 15, 0), "it.admin", "svc_patch", "Administrators", "SRV-FILE-01")
    group_add(at(9, 11, 0), "it.admin", "m.garcia", "VPN-Users", "SRV-IAM-01")

    # ------------------------------------------------------- attack scenarios
    # SC-01: external brute force against j.smith
    for i in range(120):
        login(at(4, 14, 0, i * 2), "j.smith", "203.0.113.45", "RU", "failure", "rdp", "SC-01")

    # SC-02: password spray; two rounds across 30 accounts, one weak password succeeds
    targets = rng.sample([u for u in users if u["name"] != "a.nguyen"], 29) + [by_name["a.nguyen"]]
    for rnd in range(2):
        for i, u in enumerate(targets):
            t = at(6, 3, 0) + timedelta(minutes=rnd * 20, seconds=i * 40 + rng.randint(0, 10))
            login(t, u["name"], "203.0.113.99", "CN", "failure", "o365", "SC-02")
    login(at(6, 3, 42), "a.nguyen", "203.0.113.99", "CN", "success", "o365", "SC-02")

    # SC-03: brute force -> success -> encoded PowerShell -> self-added to Domain Admins
    okafor = by_name["d.okafor"]
    for i in range(40):
        login(at(8, 9, 30, i * 9 + rng.randint(0, 3)), "d.okafor", "203.0.113.77", "BR", "failure", "rdp", "SC-03")
    login(at(8, 9, 37), "d.okafor", "203.0.113.77", "BR", "success", "rdp", "SC-03")
    payload = enc_ps("Write-Output 'detlab-sample-payload'")
    proc(at(8, 9, 48), "d.okafor", okafor["host"], "powershell.exe", "cmd.exe",
         f"powershell.exe -nop -w hidden -enc {payload}", "SC-03")
    group_add(at(8, 10, 5), "d.okafor", "d.okafor", "Domain Admins", "DC-01", "SC-03")

    # SC-04: impossible travel, US then Romania
    login(at(11, 14, 5), "r.patel", by_name["r.patel"]["ip"], "US", "success", "o365")
    login(at(11, 14, 22), "r.patel", "203.0.113.120", "RO", "success", "o365", "SC-04")

    # SC-05: Word spawns hidden, encoded PowerShell, then discovery
    lee = by_name["k.lee"]
    proc(at(12, 15, 20), "k.lee", lee["host"], "powershell.exe", "winword.exe",
         f"powershell.exe -nop -w hidden -enc {enc_ps('Write-Output detlab-sample-stage1')}", "SC-05")
    proc(at(12, 15, 21), "k.lee", lee["host"], "whoami.exe", "powershell.exe", "whoami.exe /all", "SC-05")

    # SC-06: impossible travel, US then Nigeria
    login(at(13, 16, 40), "s.ivanov", by_name["s.ivanov"]["ip"], "US", "success", "o365")
    login(at(13, 16, 48), "s.ivanov", "203.0.113.180", "NG", "success", "o365", "SC-06")

    # ---------------------------------------------------------------- finalize
    raw.sort(key=lambda e: e["_t"])  # stable sort keeps generation order for ties
    events: list[dict] = []
    scenario_events: dict[str, list[str]] = {sc: [] for sc in SCENARIOS}
    for i, row in enumerate(raw, start=1):
        event_id = f"e{i:06d}"
        sc = row.pop("_sc")
        t = row.pop("_t")
        events.append({"event_id": event_id, "ts": fmt_ts(t.timestamp()), **row})
        if sc:
            scenario_events[sc].append(event_id)

    truth = {
        "meta": {"seed": seed, "days": days, "start": START.strftime("%Y-%m-%d"),
                 "events": len(events), "users": len(users)},
        "scenarios": {sc: {**info, "event_ids": scenario_events[sc]} for sc, info in SCENARIOS.items()},
    }
    return events, truth


def write_dataset(events: list[dict], truth: dict, out_dir: str | Path) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    with open(out / "events.jsonl", "w", encoding="utf-8") as fh:
        for ev in events:
            fh.write(json.dumps(ev, separators=(",", ":")) + "\n")
    with open(out / "ground_truth.json", "w", encoding="utf-8") as fh:
        json.dump(truth, fh, indent=2)
