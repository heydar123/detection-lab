"""Sigma-style field matching.

A filter is a dict of ``field`` or ``field|modifier`` keys. All keys must match
(AND). Supported modifiers: equals (default), in, contains, startswith,
endswith, regex. String comparisons are case-insensitive except regex, which
uses whatever flags the pattern itself sets (e.g. ``(?i)``).
"""

from __future__ import annotations

import re
from functools import lru_cache
from typing import Any

VALID_OPS = {"equals", "in", "contains", "startswith", "endswith", "regex"}


@lru_cache(maxsize=256)
def _compile(pattern: str) -> re.Pattern:
    return re.compile(pattern)


def parse_key(key: str) -> tuple[str, str]:
    field, _, op = key.partition("|")
    return field, (op or "equals")


def _norm(value: Any) -> str:
    return str(value).casefold()


def _as_list(expected: Any) -> list:
    return expected if isinstance(expected, list) else [expected]


def _condition_ok(value: Any, op: str, expected: Any) -> bool:
    if value is None:
        return False
    if op == "equals":
        return _norm(value) == _norm(expected)
    if op == "in":
        return _norm(value) in {_norm(x) for x in _as_list(expected)}
    if op == "contains":
        text = _norm(value)
        return any(_norm(x) in text for x in _as_list(expected))
    if op == "startswith":
        text = _norm(value)
        return any(text.startswith(_norm(x)) for x in _as_list(expected))
    if op == "endswith":
        text = _norm(value)
        return any(text.endswith(_norm(x)) for x in _as_list(expected))
    if op == "regex":
        return _compile(str(expected)).search(str(value)) is not None
    raise ValueError(f"unknown match modifier: {op!r}")


def matches(event: dict, flt: dict) -> bool:
    """True when the event satisfies every condition in the filter."""
    for key, expected in flt.items():
        field, op = parse_key(key)
        if not _condition_ok(event.get(field), op, expected):
            return False
    return True


def excluded(event: dict, exclusions: list[dict]) -> bool:
    """True when the event matches any documented exclusion."""
    return any(matches(event, ex["match"]) for ex in exclusions)


def validate_filter(flt: Any, where: str) -> list[str]:
    errors: list[str] = []
    if not isinstance(flt, dict) or not flt:
        return [f"{where}: filter must be a non-empty mapping"]
    for key, expected in flt.items():
        field, op = parse_key(str(key))
        if not field:
            errors.append(f"{where}: empty field name in key {key!r}")
        if op not in VALID_OPS:
            errors.append(f"{where}: unknown modifier {op!r} in key {key!r}")
        if op == "regex":
            try:
                re.compile(str(expected))
            except re.error as exc:
                errors.append(f"{where}: invalid regex for {key!r}: {exc}")
    return errors
