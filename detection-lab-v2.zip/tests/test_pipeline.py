"""End-to-end checks: the shipped rules against the generated, labeled dataset."""

from pathlib import Path

import pytest

from detlab.engine import run_rules
from detlab.evaluate import evaluate
from detlab.generate import generate
from detlab.models import prepare_events
from detlab.rules import load_rules, validate_rule, validate_rules

RULES_DIR = Path(__file__).resolve().parent.parent / "rules"


@pytest.fixture(scope="module")
def rules():
    return load_rules(RULES_DIR)


@pytest.fixture(scope="module")
def dataset():
    events, truth = generate(seed=7, days=14)
    return prepare_events(events), truth


def test_shipped_rules_are_valid(rules):
    assert validate_rules(rules) == []
    assert len(rules) >= 6


def test_bundled_yaml_parses_rules_exactly_like_installed_pyyaml():
    """The bundled parser is the fallback on Pythons where PyYAML is not installed."""
    installed = pytest.importorskip("yaml")
    from detlab._vendor import yaml as bundled

    for path in sorted(RULES_DIR.glob("*.yml")):
        text = path.read_text(encoding="utf-8")
        assert bundled.safe_load(text) == installed.safe_load(text), path.name


def test_every_exclusion_has_a_reason(rules):
    for r in rules:
        for ex in r.get("exclusions", []):
            assert ex["reason"].strip()


def test_validator_rejects_bad_rules(rules):
    bad = dict(rules[0])
    bad["exclusions"] = [{"match": {"src_ip": "1.2.3.4"}}]  # no reason
    assert any("reason" in e for e in validate_rule(bad))
    bad = dict(rules[0], type="nonsense")
    assert any("unknown type" in e for e in validate_rule(bad))
    bad = dict(rules[0], attack={"tactic": "x", "technique": "1110", "technique_name": "y"})
    assert any("technique" in e for e in validate_rule(bad))
    bad = {k: v for k, v in rules[0].items() if k != "triage"}
    assert any("triage" in e for e in validate_rule(bad))
    # a YAML step containing ': ' silently becomes a dict - the validator must catch it
    bad = dict(rules[0], response=[{"Hunt for follow-on activity": "new processes"}])
    assert any("plain text" in e for e in validate_rule(bad))


def test_generator_is_deterministic():
    a, _ = generate(seed=7, days=14)
    b, _ = generate(seed=7, days=14)
    c, _ = generate(seed=8, days=14)
    assert a == b
    assert a != c


def test_generator_rejects_too_few_days():
    with pytest.raises(ValueError):
        generate(days=5)


def test_ground_truth_is_consistent(dataset):
    events, truth = dataset
    ids = {e["event_id"] for e in events}
    assert len(ids) == len(events)
    for sc in truth["scenarios"].values():
        assert sc["event_ids"] and set(sc["event_ids"]) <= ids


def test_tuned_rules_catch_every_scenario_with_no_false_positives(rules, dataset):
    events, truth = dataset
    result = evaluate(run_rules(events, rules, use_exclusions=True), truth, rules)
    for rid, row in result["per_rule"].items():
        assert row["recall"] == 1.0, f"{rid} missed {row['missed']}"
        assert row["fp"] == 0, f"{rid} has {row['fp']} false positives after tuning"
    assert result["overall"]["precision"] == 1.0
    assert result["overall"]["recall"] == 1.0


def test_untuned_rules_are_noisy_but_still_catch_everything(rules, dataset):
    events, truth = dataset
    result = evaluate(run_rules(events, rules, use_exclusions=False), truth, rules)
    assert result["overall"]["recall"] == 1.0
    noisy = [rid for rid, row in result["per_rule"].items() if row["fp"] > 0]
    assert {"DET-001", "DET-002", "DET-003", "DET-004", "DET-006"} <= set(noisy)
    assert result["overall"]["precision"] < 0.5


def test_detection_holds_across_seeds(rules):
    for seed in (1, 2, 3, 11, 42):
        events, truth = generate(seed=seed, days=14)
        prepare_events(events)
        result = evaluate(run_rules(events, rules), truth, rules)
        assert result["overall"]["recall"] == 1.0, f"seed {seed}"
        assert result["overall"]["fp"] == 0, f"seed {seed}"


def test_genuine_traveller_is_not_flagged(rules, dataset):
    events, _ = dataset
    alerts = run_rules(events, rules)
    assert not [a for a in alerts if a.rule_id == "DET-003" and a.entity["user"] == "t.brown"]


def test_backup_user_on_another_host_would_still_alert(rules):
    """The DET-004 exclusion is pinned to user AND host, so it can't be abused elsewhere."""
    cmd = "powershell.exe -NoProfile -EncodedCommand VwByAGkAdABlAC0ATwB1AHQAcAB1AHQAIAAnAHQAZQBzAHQAJwA="
    ev = [{"event_id": "e1", "_t": 1.0, "action": "process_create", "user": "svc_backup", "host": "WS-005",
           "process_name": "powershell.exe", "command_line": cmd}]
    alerts = run_rules(ev, rules)
    assert [a.rule_id for a in alerts] == ["DET-004"]
